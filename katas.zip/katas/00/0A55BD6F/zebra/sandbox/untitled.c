#include "untitled.h"
#include <stdio.h>

int hhg(char x)
{

int i, j;
char b=' ';

char startLetter=64 + x%64;


if(x=='E'){

    for (i=0; i<9; i++){

        if(i==0){
            for(j=4;j>-1;j--){
                printf("%c",b);
                printf("%c\n",startLetter+i);
            }
        }

    
        if(i==1){
            for(j=3;j>-1;j--){
                printf("%c",b);
                printf("%c\n",startLetter+i);
            }
       }


        if(i==2){
            for(j=2;j>-1;j--){
                printf("%c",b);
                printf("%c\n",startLetter+i);
            }
        }

    } // for

}  // if

    return 42;
} // function

