#include "untitled.h"
#include <string.h>
#include <stdio.h>

static void remove_spaces(char * result, const char * str)
{   
    for ( ; *str != '\0' ; str++) {
       
       if (*str != ' ') {
           *result = *str;
           result++;
       }
    }
    *result = '\0';
}

static int min ( int x , int y)
{
   if (x <= y)
       return x;
   else
       return y;
}

bool phone_list_check(Directory * dir, size_t count) 
{
   /* Trivial Cases for which loop logic won't work*/

   if (count == 0 || count == 1)
       return true;      
        
   for (size_t out_index = 0; out_index < count - 1; out_index++){
      
      for (size_t in_index = out_index + 1; in_index < count; in_index++) {
          
         char number_a[NUM_MAX];
         char number_b[NUM_MAX];
         
         remove_spaces(number_a, dir[out_index].number);
         remove_spaces(number_b, dir[in_index].number);
         
         int len = min(strlen(number_a),strlen(number_b));

         /* Ignore empty numbers for comparison */

         if (len == 0)
             continue;

         if (strncmp(number_a, number_b, len) == 0) {
           return false;
         }
      }
   }
   return true;
}   
