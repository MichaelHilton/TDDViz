#include "untitled.h"
#include <assert.h>
#include <stdio.h>
#define ARRAY_SIZE(array) sizeof(array)/sizeof(array[0])


Directory dir_b[3] ={
                      {"Joe", "981074242"},
                      {"Ane", "981056341"},
                      {"Anonymous", "9131421423"}
                    };


Directory dir_c[5] ={
                      {"Joe", "911074242"},
                      {"Ane", "911"},
                      {"Anonymous", "9121421423"},
                      {"John", ""},
                      {"Sam", "5212"}
                    };


Directory dir_d[7] ={
                      {"Joe", ""},
                      {"Ane", "1"},
                      {"Anonymous", "4"},
                      {"John", "7"},
                      {"Sam", "0"},
                      {"Chloe", "89"},
                      {"Anna", " "}
                     };

Directory dir_e[3] ={
                      {"Emergency", "911"},
                      {"Bob", "91 12 54 26"},
                      {"Alice", "97 625 992"}
                      
                     };

Directory dir_f[3] ={
                      {"Bob", "91 99 54 26"},
                      {"Alice", "97 625 992"},
                      {"Emergency", "911"},
                     };

Directory dir_g[3] ={
                      {"Bob", "91 62 55 993"},
                      {"Alice", "91 62 55 992"},
                      {"Emergency", "911"},
                     };

/* Small */

Directory dir_h[1] ={
                      {"Bob", "91 62 55 993"},
                    };
 
static void test_phone_directory_check_for_consistency_returns_true(void)
{
    assert(phone_list_check(dir_b, ARRAY_SIZE(dir_b)));
    assert(phone_list_check(dir_d, ARRAY_SIZE(dir_d)) == true);   
    assert(phone_list_check(dir_f, ARRAY_SIZE(dir_f)) == true); 
    assert(phone_list_check(dir_g, ARRAY_SIZE(dir_g)) == true);
    assert(phone_list_check(dir_h, ARRAY_SIZE(dir_h)) == true); 
}


static void test_phone_directory_check_for_consistency_returns_false(void)
{
    Directory dir_a[3] ={
                          {"Joe",       "981074242"},
                          {"Ane",       "9810"},
                          {"Anonymous", "9131421423"}
                        };
    assert(!phone_list_check(dir_a, ARRAY_SIZE(dir_a)));


    assert(phone_list_check(dir_c, ARRAY_SIZE(dir_c)) == false);
    assert(phone_list_check(dir_e, ARRAY_SIZE(dir_e)) == false);
}

typedef void test(void);

static test * tests[ ] =
{
    test_phone_directory_check_for_consistency_returns_true,
    test_phone_directory_check_for_consistency_returns_false,
    (test*)0,
};

int main(void)
{
    size_t at = 0;
    while (tests[at])
    {
        tests[at++]();
        putchar('.');
    }
    printf("\n%zd tests passed", at);
    return 0;
}

