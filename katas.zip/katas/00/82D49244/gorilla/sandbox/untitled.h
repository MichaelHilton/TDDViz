#ifndef UNTITLED_INCLUDED
#define UNTITLED_INCLUDED

#include <stdbool.h>
#include <stddef.h>

#define NAME_MAX 50
#define NUM_MAX 20

struct directory_element
{
  char name[NAME_MAX];
  char number[NUM_MAX];
};

typedef struct directory_element Directory;  

bool phone_list_check(Directory *, size_t);

#endif

