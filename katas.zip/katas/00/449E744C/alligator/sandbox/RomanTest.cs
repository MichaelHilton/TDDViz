
using NUnit.Framework;

[TestFixture]
public class RomanTest
{
    void TestRomanNumber(string expected, int value){
        string result = Roman.Convert(value);
        Assert.AreEqual(expected, result);
    }

    [Test]
    public void Test_1()
    {
        TestRomanNumber("I", 1);
    }

    [Test]
    public void Test_2()
    {
        TestRomanNumber("II", 2);
    }

    [Test]
    public void Test_3()
    {
        TestRomanNumber("III", 3);
    }

    [Test]
    public void Test_4()
    {
        TestRomanNumber("IV", 4);
    }

    [Test]
    public void Test_5()
    {
        TestRomanNumber("V", 5);
    }

    [Test]
    public void Test_6()
    {
        TestRomanNumber("VI", 6);
    }

    [Test]
    public void Test_7()
    {
        TestRomanNumber("VII", 7);
    }

    [Test]
    public void Test_9()
    {
        TestRomanNumber("IX", 9);
    }

}

