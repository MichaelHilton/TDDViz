
public class Roman
{
    public static string Convert(int value)
    {
        string result = "";
        if(value >= 5){
            result += "V";
            value -= 5;
        }
        if(value <= 3){
            for(int i = 0; i < value; i++)
                result += "I";
        }
        else result = "IV";
        return result;
    }
}
