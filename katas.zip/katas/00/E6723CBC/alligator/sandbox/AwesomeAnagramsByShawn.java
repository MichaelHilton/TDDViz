import java.util.*;

public class AwesomeAnagramsByShawn {
    
   public static List<String> printAnagrams(String p, String w) {
        List<String> result = new ArrayList<String>();
        if (w.length() <= 1) {
            result.add(p + w);
        }
        else {
            for(int i=0; i<w.length(); i++) {
                String before = w.substring(0, i);
                String cur = w.substring(i, i+1);
                String after = w.substring(i+1);
                result.addAll(printAnagrams(p + cur, before + after));
            }    
        }
        return result;
    }
}