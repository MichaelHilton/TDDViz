import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;

public class BestTest {
    
    static String answers = "biro bior brio broi boir bori ibro ibor irbo irob iobr iorb rbio rboi ribo riob roib robi obir obri oibr oirb orbi orib";
    
    @Test
    public void test_thingy() {
        List<String> strings = AwesomeAnagramsByShawn.printAnagrams("", "biro");
        assertNotNull(strings);
        
        for(String a : answers.split(" ")) {
            assertTrue(strings.contains(a));
        }    
        
        for(String s : strings) {
            System.out.println(s);
        }
    }
}