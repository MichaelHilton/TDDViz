import java.util.*;
import java.util.logging.Logger;

public class Untitled {

    private final static Logger logger = Logger.getLogger(Untitled.class .getName());

    public static String removeChar(int position, String text) {

            String result = "";

            if (position != 0) {
                result += text.substring(0, position);
            }

            result += text.substring(position + 1);

            return result;
    }

    // Only works for a four character string
    public static List<String> solutionOne(String givenWord) {

        List<String> possibleWords = new ArrayList<String>();

        for (int i = 0;i < givenWord.length(); i++) {

            String firstLetter = givenWord.substring(i, i + 1);
            String threeLetters = Untitled.removeChar(i, givenWord);

            for (int j = 0;j < threeLetters.length(); j++) {

                String secondLetter = threeLetters.substring(j, j + 1);
                String twoLetters = Untitled.removeChar(j, threeLetters);

                for (int x = 0;x < twoLetters.length(); x++) {

                    String thirdLetter = twoLetters.substring(x, x + 1);
                    String lastLetter = Untitled.removeChar(x, twoLetters);

                    possibleWords.add(firstLetter + secondLetter + thirdLetter + lastLetter);
                }
            }
        }

        return possibleWords;
    }
}