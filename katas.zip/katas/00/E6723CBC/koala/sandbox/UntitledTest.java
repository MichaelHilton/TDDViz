import org.junit.*;
import java.util.*;
import static org.junit.Assert.*;
import java.util.logging.Logger;

public class UntitledTest {

    private List<String> possibleWords = new ArrayList<String>(Arrays.asList(
        "biro",
        "bior",
        "brio",
        "broi",
        "boir",
        "bori",
        "ibro",
        "ibor",
        "irbo",
        "irob",
        "iobr",
        "iorb",
        "rbio",
        "rboi",
        "ribo",
        "riob",
        "roib",
        "robi",
        "obir",
        "obri",
        "oibr",
        "oirb",
        "orbi",
        "orib"
    ));

    private final static Logger logger = Logger.getLogger(UntitledTest.class .getName());

    @Test
    public void testSolutions() {

        List<String> solutionOneResults = Untitled.solutionOne("biro");

        checkAllPossibilities(solutionOneResults);
    }

    private void checkAllPossibilities(List<String> results) {

        // Make sure we got all possibilities
        for (int i = 0;i<possibleWords.size();i++) {
            assertTrue(results.contains(possibleWords.get(i)));
        }
    }
}
