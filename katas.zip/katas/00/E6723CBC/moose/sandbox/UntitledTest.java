import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;

public class UntitledTest {

    @Test
    public void nullTest() {
        assertEquals(new HashSet<String>(), Untitled.anagrams(null));
        assertEquals(new HashSet<String>(), Untitled.anagrams(""));
    }
    
    @Test
    public void hi() {
        Set<String> set = new HashSet<String>();
        set.add("hi");
        set.add("ih");
        assertEquals(set, Untitled.anagrams("hi"));
    }

    @Test
    public void h() {
        Set<String> set = new HashSet<String>();
        set.add("h");
        assertEquals(set, Untitled.anagrams("h"));
    }

    @Test
    public void aa() {
        Set<String> set = new HashSet<String>();
        set.add("aa");
        assertEquals(set, Untitled.anagrams("aa"));
    }

    @Test
    public void bigOne() {
        Set<String> set = new HashSet<String>();
        set.add("biro");
        set.add("bior");
        set.add("brio");
        set.add("broi");
        set.add("boir");
        set.add("bori");
        set.add("ibro");
        set.add("ibor");
        set.add("irbo");
        set.add("irob");
        set.add("iobr");
        set.add("iorb");
        set.add("rbio");
        set.add("rboi");
        set.add("ribo");
        set.add("riob");
        set.add("roib");
        set.add("robi");
        set.add("obir");
        set.add("obri");
        set.add("oibr");
        set.add("oirb");
        set.add("orbi");
        set.add("orib");
        assertEquals(set, Untitled.anagrams("robi"));
    }

    @Test
    public void huuuuge() {
        assertEquals(10*9*8*7*6*5*4*3*2, Untitled.anagrams("abcdefghij").size());
    }
}
