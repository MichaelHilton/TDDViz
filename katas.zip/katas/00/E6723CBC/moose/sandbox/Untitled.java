import java.util.*;

public class Untitled {
    
    public static Set<String> anagrams(String word) {
        Set<String> set = new HashSet<String>();
        if (word == null || word.equals("")) return set;
        if (word.length() == 1) {
            set.add(word);
            return set;
        }
        for (int i = 0; i < word.length(); i++) {
            StringBuilder sb = new StringBuilder(word);
            String sub = sb.deleteCharAt(i).toString();
            Set<String> subAnagrams = anagrams(sub);
            for (String s : subAnagrams) {
                StringBuilder sb2 = new StringBuilder(s);                   
                set.add(sb2.insert(0, word.charAt(i)).toString());
            }
        }
        return set;
    }
}
