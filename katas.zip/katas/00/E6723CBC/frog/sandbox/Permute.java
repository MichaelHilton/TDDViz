
import java.util.*;

public class Permute {
    
    public static Set<String> permute(String s){
        Set<String> set = new HashSet<String>();
        if (s.length() == 1){
            set.add(s);
            return set;
        }
        for (int i = 0; i < s.length(); i++){
            // set.addAll(prepend(permute(strip(s, s.charAt(i))), s.charAt(i)));
            char current = s.charAt(i);
            String strippedString = strip(s, current);
            Set<String> subset = permute(strippedString);
            subset = prepend(subset, current);
            set.addAll(subset);
        }        

        return set;
    }

    public static String strip(String s, char c){
        int i = s.indexOf(c);        
        return s.substring(0,i) + s.substring(i+1, s.length());
    }

    public static Set<String> prepend(Set<String> set, char prefix){
        // Add prefix to all members of the set
        Set<String> ret = new HashSet<String>();
        for (String s:set){
            ret.add(prefix + s);
        }
        return ret;
    } 

}