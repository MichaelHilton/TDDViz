import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;

public class UntitledTest {
    
    @Test
    public void testSingle() {
        Set<String> s = Permute.permute("a");
        assertTrue(s.contains("a"));
    }

    @Test
    public void testDouble() {
        Set<String> s = Permute.permute("ab");
        assertTrue(s.contains("ab"));
        assertTrue(s.contains("ba"));
    }

    @Test
    public void testTriple() {
        Set<String> s = Permute.permute("abc");
        assertTrue(s.contains("abc"));
        assertTrue(s.contains("acb"));
        assertTrue(s.contains("cab"));
        assertTrue(s.contains("cba"));
        assertTrue(s.contains("bac"));
        assertTrue(s.contains("bca"));
    }

    @Test 
    public void testSixSize() {
        Set<String> s = Permute.permute("abcdef");
        assertEquals(s.size(), 720);
    }

    @Test
    public void testPrepend() {
        Set<String> s = new HashSet<String>();
        s.add("e");
        s.add("f");
        s.add("g");
        s = Permute.prepend(s, 'a');
        assertTrue(s.contains("ae"));
        assertTrue(s.contains("af"));
        assertTrue(s.contains("ag"));
    }

    @Test
    public void testStrip() {
        assertEquals(Permute.strip("abc", 'b'), "ac");
        assertEquals(Permute.strip("ab", 'b'), "a");
        assertEquals(Permute.strip("ab", 'a'), "b");
    }

    @Test
    public void baseCase() {
        System.out.print("\n");
        int count = 0;
        for (String s: Permute.permute("biro")) {
            count ++;
            System.out.print(s + " ");
            if (count%6==0) {
                 System.out.print("\n");
            }
        }
    }
    
}