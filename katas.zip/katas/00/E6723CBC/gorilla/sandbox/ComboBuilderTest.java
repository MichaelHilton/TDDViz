import java.util.*;
import org.junit.*;
import static org.junit.Assert.*;

public class ComboBuilderTest {
    
    @Test
    public void comboTest() {
        ArrayList<String> asdfgh = ComboBuilder.getCombos("asdfgh");
        assertEquals(6*5*4*3*2*1, asdfgh.size());

        ArrayList<String> mch = ComboBuilder.getCombos("mch");
        assertTrue(mch.contains("mch"));
        assertTrue(mch.contains("mhc"));
        assertTrue(mch.contains("cmh"));
        assertTrue(mch.contains("chm"));
        assertTrue(mch.contains("hmc"));
        assertTrue(mch.contains("hcm"));
    }

    
}
