import java.util.*;

public class ComboBuilder {

    public static ArrayList<String> getCombos(String word) {
        StringBuffer sbuf = new StringBuffer(word);
        ArrayList<String> allCombos = new ArrayList<String>();

        if (word.length() == 1) {
            allCombos.add(word.toString());
            return allCombos;
        }       
        
        for (int i=0; i < sbuf.length(); i++) {
            StringBuffer remainingPossibilites = new StringBuffer(word);
            String popedLetter = Character.toString(sbuf.charAt(i));
            remainingPossibilites.deleteCharAt(i);
            
            for (String combo : getCombos(remainingPossibilites.toString())) {
                allCombos.add(popedLetter + combo);
            }
        }
        
        return allCombos;

    }

}
