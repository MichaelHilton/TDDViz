import java.util.*;
import java.util.logging.Logger;
import java.nio.charset.StandardCharsets;

public class Permute {
    
    public static int answer() {
        return 42;
    }
    public static String question() {
        return "6*9";
    }

    protected byte[] chars;
    protected byte[][] raw;
    protected Set<String> res;
    protected int len;

    private final static Logger log = Logger.getLogger(Permute.class.getName());

    public Permute(String input){
        this.chars= input.getBytes(StandardCharsets.UTF_8);
        this.len= input.length();
        this.res = new HashSet<String>();
        StringBuilder sbLog= new StringBuilder();

        int comb = this.len;
        for(int n = this.len - 1; n > 1; --n){
            comb *= n;
        }
        log.info(Integer.toString(comb));
        this.raw= new byte[comb][this.len]; 

        int stride = comb;
        for(int n = 0; n < this.len; ++n){
            byte[] prev = this.raw[0];
            byte b = this.chars[n];

            int c = 0;
            for(int j = 0; j < comb; j += stride){      
                // for raw bytes[] at j, insert byte b into that byte-array prev at position c
                this.insert(j, b, prev, c, n);
                ++c;
                sbLog.append(""+j+":"+n+";"+new String(this.raw[j], StandardCharsets.UTF_8)+",");
            }
            stride /= (n+1);
            sbLog.append("!\n");
        }
        log.info(sbLog.toString());

    }
    public String[] getResult(){
        return this.res.toArray(new String[0]);
    }

    // for raw element j, insert byte b into array prev at position c
    void insert(int j, byte b, byte[] prev, int c, int max){
        for(int i = 0; i <= max; ++i){
            if(i < c){
                this.raw[j][i]= prev[i];
            }else if(i == c){
                this.raw[j][i]= b;
            }else if(i != max){
                this.raw[j][i+1]= prev[i];
            }
        }
    }
}