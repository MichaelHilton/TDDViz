import org.junit.*;
import java.util.Arrays;
import java.util.logging.Logger;
import static org.junit.Assert.*;

public class PermuteTest {

    private final static Logger log = Logger.getLogger(PermuteTest.class.getName());

    static String[] result = new String[]{
        "biro",
        "bior",
        "brio",
        "broi",
        "boir",
        "bori",
        "ibro",
        "ibor",
        "irbo",
        "irob",
        "iobr",
        "iorb",
        "rbio",
        "rboi",
        "ribo",
        "riob",
        "roib",
        "robi",
        "obir",
        "obri",
        "oibr",
        "oirb",
        "orbi",
        "orib"};

    @Test
    public void hitch_hiker() {

        //int expected = 6 * 7;
        //int actual = Untitled.answer();
        //assertEquals(expected, actual);
        //List<String> necessary= Arrays.asList(result);

        Permute perm = new Permute("12345");
        String[] res = perm.getResult();
        //StringBuilder sb = new StringBuilder();
        //for(int i = 0; i < res.length; ++i){
        //    sb.append(res[i]);
        //    sb.append(",");
        //}
        //System.out.println(sb.toString());
    }
}