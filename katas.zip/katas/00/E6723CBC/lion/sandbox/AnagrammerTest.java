import org.junit.*;
import static org.junit.Assert.*;

public class AnagrammerTest {
    
    @Test
    public void test_single_character_returns_itself() {
        String expected = "a";
        StringBuilder actual = Anagrammer.printAnagrams("a");
        assertEquals(expected, actual);
    }

}
