import java.lang.StringBuilder;
import java.util.ArrayList;

public class Anagrammer {
    
    public static StringBuilder printAnagrams(String input){
        ArrayList<Character> iterableString = input.toCharArray();

        StringBuilder anagramList = new StringBuilder();

        for (int i = 0; i <= iterableString.length; i++){
            anagramList = anagramList.append(iterableString[i]);
        }

        return anagramList;
    }
}