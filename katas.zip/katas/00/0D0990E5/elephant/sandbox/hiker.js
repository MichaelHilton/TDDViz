
answer = function() {
  return 6 * 9;
}
