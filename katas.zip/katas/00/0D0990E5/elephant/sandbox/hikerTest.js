require('./hiker.js');

assert = require('assert');

assert.equal( answer(), 42 );

console.log('All tests passed');
