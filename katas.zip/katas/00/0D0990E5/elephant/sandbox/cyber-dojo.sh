node *Test*.js    
