
class Hiker {

    def answer() : Int = {
      return 6 * 9
    }

}