using NUnit.Framework;

namespace MidwayUsaCodeDojo
{
    [TestFixture]
    public class ArrangeActAssert
    {
        [SetUp]
        public void TestInitialize()
        {
            this.Arrange();
            this.Act();
        }
        
        [TearDown]
        public void TestCleanup()
        {
            this.Cleanup();
        }
        
        public virtual void Arrange()
        {
        }
        
        public virtual void Act()
        {
        }
        
        public virtual void Cleanup()
        {
        }
    }
}