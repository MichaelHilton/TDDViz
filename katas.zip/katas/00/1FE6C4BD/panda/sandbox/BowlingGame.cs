namespace MidwayUsaCodeDojo
{
    public class BowlingGame
    {
        public int CalculateScore(char[] game)
        {
            int totalScore = 0;
            
            for(int i=0; i < 22; i++)
            {
                if(game[i] == '-')
                {
                    totalScore = totalScore + 0;
                }

                else
                {
                    totalScore = totalScore + int.Parse(game[i].ToString());
                }
            }

            return totalScore;
        }
    }
}