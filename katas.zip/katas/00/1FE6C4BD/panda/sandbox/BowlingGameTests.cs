using NUnit.Framework;

namespace MidwayUsaCodeDojo
{
    [TestFixture]
    public class WithANewBowlingGame : ArrangeActAssert
    {
        private BowlingGame Sut = new BowlingGame();      
        private char[] GutterGame = new char[]{'-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-'};
        private char[] NoStrikesOrSpares = new char[]{'1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','0','0'};              
        private int result;

        [TestFixture]
        public class AndGutterGame : WithANewBowlingGame
        {
            [Test]
            public void ScoreIsZero()
            {
                Assert.AreEqual(0, result);
            }

            public override void Act()
            {
                result = Sut.CalculateScore(GutterGame);
            }
        }

        [TestFixture]
        public class AndNoStrikesOrSparesGame : WithANewBowlingGame
        {
            [Test]
            public void ScoreIsCalculatedCorrectly()
            {
                Assert.AreEqual(20, result);
            }

            public override void Act()
            {
                result = Sut.CalculateScore(NoStrikesOrSpares);
            }
        }

        [TestFixture]
        public class AndAllStrikes : WithANewBowlingGame
        {
            private char[] AllStrikes = new char[]{'X','0','X','0','X','0','X','0','X','0','X','0','X','0','X','0','X','0','X','0','X','X'};            

            [Test]
            public void ScoreIsThreeHundred()
            {
                Assert.AreEqual(300, result);
            }

            public override void Act()
            {
                result = Sut.CalculateScore(AllStrikes);
            }
        }        
    }
}