using System;

namespace MidwayUsaCodeDojo
{
    public class BowlingScorer
    {
        public static int Answer
        {
            get { return 42; }
        }

        public int Score(int[] scores)
        {
            int result = 0;
            foreach (int score in scores)
            {
                if (score < 0 || score > 10) throw new Exception();
                result += score;
            }
            return result;
        }
    }
}