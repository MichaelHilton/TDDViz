using NUnit.Framework;
using System;

namespace MidwayUsaCodeDojo
{
    [TestFixture]
    public class BowlingTest : ArrangeActAssert
    {
        public class WithANewBowlingScorer : BowlingTest
        {
            private int result;
            
            private int[] gameScores;

            private BowlingScorer Sut { get; set; }

            public override void Arrange()
            {
                this.Sut = new BowlingScorer();
            }

            public override void Act()
            {
                this.result = this.Sut.Score(this.gameScores);
            }

            [TestFixture]
            public class AndScoresAreInvalid : WithANewBowlingScorer
            {
                [Test]
                public void AnExceptionIsThrown()
                {
                    Assert.Throws<Exception>(this.Act);
                }

                public class AndANegativeScoreIsSubmitted : AndScoresAreInvalid
                {
                    public override void Arrange()
                    {
                        base.Arrange();
                        this.gameScores = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1};     
                    }
                }

                public override void Arrange()
                {
                    base.Arrange();
                    this.gameScores = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11};
                }       
            }

            [TestFixture]
            public class AndScoresAreValid : WithANewBowlingScorer
            {
                public class AndNoStrikesAndSpares : AndScoresAreValid
                {
                    [Test]
                    public void TheScoresAddUp()
                    {
                        Assert.AreEqual(20, this.result);
                    }

                    public override void Arrange()
                    {
                        base.Arrange();
                        this.gameScores = new int[]{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
                    }
                }
                

                [Test]
                public void TheScoreIsZeroOrGreater()
                {
                    Assert.IsTrue(this.result >= 0);
                }

                public override void Arrange()
                {
                    base.Arrange();
                    this.gameScores = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
                }
            }
        }
    }
}