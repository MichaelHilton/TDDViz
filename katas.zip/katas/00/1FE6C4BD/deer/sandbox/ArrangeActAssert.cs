using NUnit.Framework;

namespace MidwayUsaCodeDojo
{
    [TestFixture]
    public class ArrangeActAssert
    {
        [SetUp]
        public void TestInitialize()
        {
            try
            {
                this.Arrange();
                this.Act();
            }
            catch
            {
            }
        }
        
        [TearDown]
        public void TestCleanup()
        {
            this.Cleanup();
        }
        
        public virtual void Arrange()
        {
        }
        
        public virtual void Act()
        {
        }
        
        public virtual void Cleanup()
        {
        }
    }
}