import org.junit.*;
import static org.junit.Assert.*;

public class CellTest {
    @Test
    public void testGetLiveCell () {
        Cell target = LiveCell.INSTANCE;
        assertTrue(target.isAlive());
    }
    
    @Test
    public void testGetDeadCell(){
        Cell target = DeadCell.INSTANCE;
        assertFalse(target.isAlive());
    }
}