public class LiveCell extends Cell {
    public static final Cell INSTANCE = new LiveCell();

    private LiveCell(){
    }

    public boolean isAlive(){
        return true;
    }
}