public abstract class Cell {
    public abstract boolean isAlive();
}