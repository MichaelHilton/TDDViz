package fizz_buzz

import "strconv"

func fizz_buzz (x int) string {
    if x % 15 == 0 { return "FizzBuzz"; }
    if x % 5 == 0 { return "Buzz"; }
    if x % 3 == 0 { return "Fizz"; }
    return strconv.Itoa (x);
}