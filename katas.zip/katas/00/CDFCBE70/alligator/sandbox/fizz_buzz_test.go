package fizz_buzz

import (
    "testing"
    "fmt"
)

func Test_fizz_for_multiples_of_three(t *testing.T) {
    for i := 3; i < 100; i += 3 {
        if i % 5 == 0 { continue }
        if fizz_buzz (i) != "Fizz" {
            error_message := fmt.Sprintf("fizz_buzz (%d) != Fizz", i)
            t.Error (error_message)
            break
        }
    }
}

func Test_buzz_for_multiples_of_five(t *testing.T) {
    for i := 5; i < 100; i += 5 {
        if i % 3 == 0 { continue }
        if fizz_buzz (i) != "Buzz" {
            error_message := fmt.Sprintf("fizz_buzz (%d) != Buzz", i)
            t.Error (error_message)
            break
        }
    }
}

func Test_buzz_for_multiples_of_fiveteen(t *testing.T) {
    for i := 15; i < 100; i += 15 {        
        if fizz_buzz (i) != "FizzBuzz" {
            error_message := fmt.Sprintf("fizz_buzz (%d) != FizzBuzz", i)
            t.Error (error_message)
            break
        }
    }
}