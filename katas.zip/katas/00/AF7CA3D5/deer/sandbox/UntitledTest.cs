
using NUnit.Framework;

[TestFixture]
public class UntitledTest
{
    [Test]
    public void Check1904True()
    {
        var checker = new LeapYearChecker();
        bool expected = true;
        bool actual = checker.IsLeapYear(1904);
        Assert.AreEqual(expected, actual);
    }
}
