
public class LeapYearChecker
{
    public static int Answer
    {
        get { return 42; }
    }

    public bool IsLeapYear(int year)
    {
        return year % 4 == 0;
    }
}
