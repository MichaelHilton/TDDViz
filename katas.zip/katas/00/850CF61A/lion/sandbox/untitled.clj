(ns untitled)

(defn answer [ ]
  42)
  