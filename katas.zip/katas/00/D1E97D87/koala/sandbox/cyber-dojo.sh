# Test output can be formatted as progress or documentation
cucumber -f progress .