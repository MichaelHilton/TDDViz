
public class FizzBuzz {
    
    public void run() {
        System.out.println("");
        for (int i = 1; i < 100; i++) {
            System.out.println(determineOutput(i));
        }
    }
    
    public String determineOutput(Integer number) {
        StringBuffer output = new StringBuffer();
        if ((number%3)== 0) {
            output.append("Fizz");
        } 
        if ((number%5)== 0) {
            output.append("Buzz");
        }
        if (output.length() == 0) {
            output.append(number.toString());
        }
        return output.toString();
    }
}
