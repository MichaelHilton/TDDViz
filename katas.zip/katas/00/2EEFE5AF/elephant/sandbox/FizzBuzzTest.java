import org.junit.*;
import static org.junit.Assert.*;

public class FizzBuzzTest {
    
    @Test
    public void testNumberOutput() {
        String expected = "2";
        String actual = new FizzBuzz().determineOutput(2);
        assertEquals(expected, actual);
    }

    @Test
    public void testFizzOutput() {
        String expected = "Fizz";
        String actual = new FizzBuzz().determineOutput(3);
        assertEquals(expected, actual);
    }

    @Test
    public void testBuzzOutput() {
        String expected = "Buzz";
        String actual = new FizzBuzz().determineOutput(5);
        assertEquals(expected, actual);
    }

    @Test
    public void testFizzBuzzOutput() {
        String expected = "FizzBuzz";
        String actual = new FizzBuzz().determineOutput(15);
        assertEquals(expected, actual);
    }

    @Test
    public void runFizzBuzz() {
        FizzBuzz fizzBuzz = new FizzBuzz();
        fizzBuzz.run();
    }
}
