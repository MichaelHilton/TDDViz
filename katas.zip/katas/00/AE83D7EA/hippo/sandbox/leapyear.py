class leapyear:
    
    def __init__(self, year):
        self.year = year;

    def isLeapYear(self):
        if ( (self.year % 400) == 0 ):
            return True;
        elif ( (self.year % 100) == 0 ):
            return False;
        elif ( (self.year % 4) == 0 ):
            return True;
        else:
            return False;
