import leapyear
import unittest

class Testleapyear(unittest.TestCase):

    def test_odd(self):
        obj = leapyear.leapyear(2013)
        self.assertEqual(False, obj.isLeapYear())

    def test_normal_leapyear(self):
        obj  = leapyear.leapyear(2012)
        self.assertEqual(True, obj.isLeapYear())    

    def test_century_no_leapyear(self):
        obj  = leapyear.leapyear(1900)
        self.assertEqual(False, obj.isLeapYear())    

    def test_century_leapyear(self):
        obj  = leapyear.leapyear(2000)
        self.assertEqual(True, obj.isLeapYear())    

if __name__ == '__main__':
    unittest.main()
