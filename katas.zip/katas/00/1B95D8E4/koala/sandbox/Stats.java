
public class Stats {

    public static final int NULL_RESULT = 0;

    public static int minimum(int[] input) {
        if (input.length == 0) {
            return NULL_RESULT;
        }

        int result = input[0];
        for (int i = 1; i < input.length; ++i) {
            result = smaller(input[i], result);
        }
        return result;
    }

    private static int smaller(int first, int second) {
        if (first < second) {
             return first;
        }
        return second;
    }
}