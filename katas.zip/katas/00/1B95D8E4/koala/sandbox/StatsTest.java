import org.junit.*;
import static org.junit.Assert.*;

public class StatsTest {

    private static final int[] SAMPLE_INPUT = {6, 9, 15, -2, 92, 11};
    private static final int[] TWO_ELEMENT_INPUT = {-5, 6};
    private static final int[] ONE_ELEMENT_INPUT = {42};
    private static final int[] EMPTY_INPUT = {};

    @Test
    public void testMinimum() {
        assertEquals(-2, Stats.minimum(SAMPLE_INPUT));
        assertEquals(-5, Stats.minimum(TWO_ELEMENT_INPUT));
        assertEquals(42, Stats.minimum(ONE_ELEMENT_INPUT));
        assertEquals(Stats.NULL_RESULT, Stats.minimum(EMPTY_INPUT));
    }
}