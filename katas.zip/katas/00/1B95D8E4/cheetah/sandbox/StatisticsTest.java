import org.junit.*;
import static org.junit.Assert.*;

public class StatisticsTest {

    @Test
    public void testMin() {
        int expected = 5;
        int[] data = {5,6,7};
        Result result = Statistics.calculateStatistics(data);
        assertEquals(expected, result.min);
    }

    @Test
    public void testMax() {
        int expected = 7;
        int[] data = {5,6,7};
        Result result = Statistics.calculateStatistics(data);
        assertEquals(expected, result.max);
    }

    @Test
    public void testLength() {
        int expected = 3;
        int[] data = {5,6,7};
        Result result = Statistics.calculateStatistics(data);
        assertEquals(expected, result.length);
    }
}
