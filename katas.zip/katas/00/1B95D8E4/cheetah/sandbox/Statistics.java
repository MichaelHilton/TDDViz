
public class Statistics {

    public static Result calculateStatistics(int[] a) {
        Result result = new Result();
        result.min = a[0];
        result.max = a[0];
        result.length = 0;
        for (int x : a) {
            if (x < result.min) {
                result.min = x;
            }
            if (x > result.min) {
                result.max = x;
            }
            result.length++;
        }
        return result;
    }
}
