
public class Hiker {

    public static int minimum(int[] array) {
        int minValue = array[0];  
        for(int i=1;i<array.length;i++){  
            if(array[i] < minValue){  
                minValue = array[i];  
            }  
         }  
        return minValue;
    }
    public static int maximum(int[] array) {
        int maxValue = array[0];  
        for(int i=1;i < array.length;i++){  
            if(array[i] > maxValue){  
                maxValue = array[i];  
            }  
        }  
        return maxValue;  
    }
    public static double average(int[] array) {
        int num = number(array);
        double sum=0;
        for(int i=0;i<num;i++){
            sum+=array[i];
        }
        sum=sum/num;
    return sum;
    }
    public static int number(int[] array) {
        return array.length;
    }
}
