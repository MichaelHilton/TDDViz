import org.junit.*;
import static org.junit.Assert.*;

public class HikerTest {

    @Test
    public void max_test() {
        int[] array= { 10000, 1, 2, 6, 24, 120, 720, 5040 };
        int actual = Hiker.maximum(array);
        assertEquals(10000, actual);
    }

    @Test
    public void min_test() {
        int[] array= { 10000, 1, 2, -6, 24, 120, 720, 5040 };
        int actual = Hiker.minimum(array);
        assertEquals(-6, actual);
    }

    @Test
    public void num_test() {
        int[] array= { 10000, 1, 2, 6, 24, 120, 720, 5040 };
        int actual = Hiker.number(array);
        assertEquals(8, actual);
    }

    @Test
    public void average_test() {
        int[] array= { 0,5,10 };
        double actual = Hiker.average(array);
        assertEquals(5, actual,0.01);
    }
}
