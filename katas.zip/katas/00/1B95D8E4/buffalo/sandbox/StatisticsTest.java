import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;

public class StatisticsTest {

    private List<Integer> testList1 = Arrays.asList(6, 9, 15, -2, 92, 11);
    private List<Integer> testList2 = Arrays.asList();
    
    @Test
    public void MinimumTestWithNonEmptyList() {
        
          int expected = -2;
          int actual = Statistics.minimum(testList1);
          assertEquals(expected, actual);
    }
    
    @Test(expected=IllegalArgumentException.class)
    public void MinimumTestWithEmptyList() {
  
          Statistics.minimum(testList2);      
    }


    @Test
    public void MaximumTest() {
        
       // int actual = Statistics.answer();
       // assertEquals(expected, actual);
    }
    
    @Test  
    public void LengthTestWithNonEmptyList() {
        
        int expected = testList1.size();
        int actual = Statistics.length(testList1);
        assertEquals(expected, actual);
    } 

    @Test
    public void LengthTestWithEmptyList() {
        
        int expected = testList2.size();
        int actual = Statistics.length(testList2);
        assertEquals(expected, actual);
    } 

    @Test
    public void AvarageTest() {
        
       // int actual = Statistics.answer();
       // assertEquals(expected, actual);
    }
}