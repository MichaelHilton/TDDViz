import java.util.*;

public class Statistics{

    public static int length(List<Integer> numbers) {
        return numbers.size();
    }
    
    public static int minimum(List<Integer> numbers) {
        if(numbers.isEmpty()) {
            throw new IllegalArgumentException();   
        }      
        Collections.sort(numbers);
        return numbers.get(0);
    }
    
}