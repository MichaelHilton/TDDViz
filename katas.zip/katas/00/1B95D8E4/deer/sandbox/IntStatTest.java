import org.junit.*;
import static org.junit.Assert.*;

public class IntStatTest {

    public static final int[] SAMPLE_NUMBERS = {6, 9, 15, -2, 92, 11};

    @Test
    public void testMinimumCorrect() {
        assertEquals(-2, IntStat.getMin(SAMPLE_NUMBERS));
    }

    @Test
    public void testMaximumCorrect() {
        assertEquals(92, IntStat.getMax(SAMPLE_NUMBERS));
    }

    @Test
    public void testCountCorrect() {
        assertEquals(6, IntStat.getCount(SAMPLE_NUMBERS));
    }

    @Test
    public void testAvgCorrect() {
        assertEquals(131 / 6.0, IntStat.getAvg(SAMPLE_NUMBERS), 0.001);
    }

}