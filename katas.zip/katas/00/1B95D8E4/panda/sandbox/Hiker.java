import java.util.ArrayList;
 
public class Hiker {


    public static int getMin(ArrayList<Integer> listNumbers) {
        int listSize = listNumbers.size();
        int tempMin = listNumbers.get(0);
        for (int i=1; i<listSize;i++){
              if (listNumbers.get(i) < tempMin) { 
                tempMin = listNumbers.get(i); 
                }
        }
        return tempMin;
    }
     public static int getMax(ArrayList<Integer> listNumbers) {
        int listSize = listNumbers.size();
        int tempMax = listNumbers.get(0);
        for (int i=1; i<listSize;i++){
              if (listNumbers.get(i) > tempMax) { 
                tempMax = listNumbers.get(i); 
                }
           }
        return tempMax;
    }
    public static int getSize(ArrayList<Integer> listNumbers) {
        int listSize = listNumbers.size();  
        return listSize;
    }
    public static double getAvg(ArrayList<Integer> listNumbers) {
        int listSize = listNumbers.size();
        int Sum = 0;
        for (int i=0; i<listSize;i++){
              Sum = Sum + listNumbers.get(i);
           }
        return  Sum / listSize;
    }
    

}
