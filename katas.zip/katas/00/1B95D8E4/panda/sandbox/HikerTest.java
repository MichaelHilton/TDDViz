import org.junit.*;
import static org.junit.Assert.*;
import java.util.ArrayList;
 

public class HikerTest {

    ArrayList<Integer> listNumbers;
    
    @Test
    public void minTest() {
         listNumbers = new ArrayList<Integer>();
        listNumbers.add(42);
        listNumbers.add(11);
        listNumbers.add(4);

        int expected = 4;
        int actual = Hiker.getMin(listNumbers);
        assertEquals(expected, actual);

    }
    @Test
    public void maxTest() {
         listNumbers = new ArrayList<Integer>();
        listNumbers.add(42);
        listNumbers.add(11);
        listNumbers.add(4);

        int expected = 42;
        int actual = Hiker.getMax(listNumbers);
        assertEquals(expected, actual);

    }
    @Test
    public void sizeTest() {
        listNumbers = new ArrayList<Integer>();
        listNumbers.add(42);
        listNumbers.add(11);
        listNumbers.add(4);

        int expected = 3;
        int actual = Hiker.getSize(listNumbers);
        assertEquals(expected, actual);

    }
   

}
