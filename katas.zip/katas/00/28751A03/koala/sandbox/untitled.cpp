#include "untitled.hpp"

int hhg()
{
    return 42;
}


