#include "untitled.hpp"
#include <cassert>
#include <iostream>

static void example()
{
    assert(hhg() == 6*9);
}

int main()
{
    example();
    std::cout << "All tests passed";
}
