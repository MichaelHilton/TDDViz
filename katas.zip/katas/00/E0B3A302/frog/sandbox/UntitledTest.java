import org.junit.*;
import static org.junit.Assert.*;

import java.io.*;

public class UntitledTest {
    
    String[] FIZZ_BUZZ_OUTPUT={"1","2","Fizz","4","Buzz","Fizz","7","8","Fizz","Buzz","11","Fizz","13","14","FizzBuzz"};
    
    @Test
    public void testAllNumbersThrough100() throws Exception {
        StringBuilder builder=new StringBuilder("");
        for(String buzz : FIZZ_BUZZ_OUTPUT) {
            builder.append(buzz);
            builder.append("\n");
        }
        // Create a stream to hold the output
           ByteArrayOutputStream baos = new ByteArrayOutputStream();
    PrintStream ps = new PrintStream(baos);
    // IMPORTANT: Save the old System.out!
    PrintStream old = System.out;
    // Tell Java to use your special stream
    System.setOut(ps);
       Untitled.fizzBuzz();
        System.out.flush();
        System.setOut(old);
        assertEquals(builder.toString(),baos.toString());
        baos.close();
   
    }

    @Test
    public void testNotAMultiple() {
         assertEquals("output should be same as input", "2",Untitled.checkFizzBuzz(2));    
    }

    @Test
    public void testMultipleOfThreeButNotFive() {
       assertEquals("output should be fizz", "Fizz",Untitled.checkFizzBuzz(3));    
    }

    @Test
    public void testMultipleOfFiveButNotThree() {
           assertEquals("output should be fizz", "Buzz",Untitled.checkFizzBuzz(5));    
    }

    @Test
    public void testFizzBuzz() {
               assertEquals("output should be fizzbuzz", "FizzBuzz",Untitled.checkFizzBuzz(30));    
    }

}