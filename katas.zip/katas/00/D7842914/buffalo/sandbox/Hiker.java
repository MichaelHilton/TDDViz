
public class Hiker {

    public static int answer() {
        return 6 * 9;
    }
}
