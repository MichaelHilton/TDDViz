
public class Untitled {
    
    public static int answer() {
        return 42;
    }
}