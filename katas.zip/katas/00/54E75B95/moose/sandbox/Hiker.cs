
public class Hiker
{
    public static int Answer
    {
        get { return 6 * 9; }
    }
}
