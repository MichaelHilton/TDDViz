
using NUnit.Framework;

[TestFixture]
public class HikerTest
{
    [Test]
    public void life_the_universe_and_everything()
    {
        // a simple example to start you off
        Assert.AreEqual(42, Hiker.Answer);
    }
}
