package untitled

func hhg() int {
    return 42
}
