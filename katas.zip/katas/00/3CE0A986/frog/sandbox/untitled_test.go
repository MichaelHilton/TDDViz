package untitled

import ("testing")

func Test_hhg(t *testing.T) {
    if (hhg() != 42) {
        t.Error("hhg() != 42 as expected.")
    }
}
