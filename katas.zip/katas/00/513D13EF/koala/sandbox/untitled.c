#include "untitled.h"

int hhg(void)
{
    return 42;
}

