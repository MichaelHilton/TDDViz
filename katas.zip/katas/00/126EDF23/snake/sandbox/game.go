package game

const(  
    worldRowCount = 3
    worldcolCount = 3
    rowCount = worldRowCount + 2
    colCount = worldColCount + 2
)

func hhg() int {
    return 54
}

func newWorld() [rowCount][colCount]int {
    return make([][]int, rowCount, colCount)
}


func neighboursCount(world [rowCount][colCount]int, r int, c int) count int {
    for i := range world {
        count += rowALiveCount(world, i, c)
    }
    return count - world[r][c]
}

func left(c int) l int{
    l = c - 1;
}

func right(c int) r int{
    r = c + 1;
}

func rowALiveCount(world [rowCount][colCount]int, i int, c int) count int {
    for j:=0; j< len(world[i]) && j>= left(c) && right(c); j++ {
            count += world[i][j]
        }
    return count
}