package game

import ("testing"
        "runtime"
        "strconv")

func AssertTrue(t *testing.T, condition bool, desc string) {                            
    _, _, line, _ := runtime.Caller(1)                                                  
    if !condition {                                                                     
        t.Error("Error line number " + strconv.Itoa(line))                              
    }                                                                                   
} 

func TestNoNeighbour(t *testing.T) {
    world := newWorld()
    AssertTrue(t, (neighboursCount(world, 1, 1) == 0), "I give false.")
}

func TestOneNeighbour(t *testing.T) {
    world := newWorld()
    world[0][0] = 1
    AssertTrue(t, (neighboursCount(world, 1, 1) == 1), "I give false.")
} 

func Test3Neighbour(t *testing.T) {
    world := newWorld()
    world[0][0] = 1
    world[0][1] = 1
    world[1][0] = 1
    world[1][1] = 1
    AssertTrue(t, (neighboursCount(world, 1, 1) == 3), "I give false.")
} 


func TestTopRightNoNeighbour(t *testing.T) {
    world := newWorld()
    right := colCount - 1
    world[0][right] = 1
    world[2][0] = 1
    AssertTrue(t, (neighboursCount(world, 0, right) == 0), "I give false.")
}




