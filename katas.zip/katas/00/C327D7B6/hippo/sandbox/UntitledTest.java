import org.junit.*;
import static org.junit.Assert.*;

public class UntitledTest {
    
    @Test
    public void hitch_hiker() {
        int expected = 1;
        int actual = Untitled.answer(500);
        assertEquals(expected, actual);
    }
}
