
public class Untitled {
    
    public static int answer(int testyear) {
       
        if(testyear%4 == 0)
        {
            if(testyear%100 == 0)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
}
