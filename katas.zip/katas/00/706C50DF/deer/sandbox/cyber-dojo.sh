ruby *test*.rb

