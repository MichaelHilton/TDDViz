package hiker

func answer() int {
    return 6 * 7
}
