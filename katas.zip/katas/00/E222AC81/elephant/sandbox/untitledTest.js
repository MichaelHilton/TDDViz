require('./untitled.js');

assert = require('assert');

var initial = [[0,0,0],[0,0,0],[0,0,0]]
assert.equal( answer(initial), initial );

var cell_index = {x:0,y:0}
assert.equal( get_living_neighbours( initial, cell_index ), 0 )

var anotherInitial = [[1,1,1],[1,1,1],[1,1,1]];
assert.equal( get_living_neighbours( anotherInitial, {x:0,y:0} ), 3 )

var anotherInitial = [[1,1,1],[1,1,1],[1,1,1]];
assert.equal( get_living_neighbours( anotherInitial, {x:1,y:1} ), 8 )

assert.equal( new_state(anotherInitial,cell_index), 0 );

var initial = [[0,1,0],[1,1,0],[0,0,0]]
assert.equal( new_state(initial,cell_index), 1 );


console.log('All tests passed');
