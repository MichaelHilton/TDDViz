
answer = function(initial) {
  return initial;
}
get_living_neighbours = function ( initial, cell_index ){
  var living = 0 
  var x =  cell_index.x
  var y = cell_index.y  
  living = living + getElemState(initial,x,y+1)
  living = living + getElemState(initial,x,y-1)
  living = living + getElemState(initial,x+1,y-1)
  living = living + getElemState(initial,x+1,y)
  living = living + getElemState(initial,x+1,y+1)
  living = living + getElemState(initial,x-1,y-1)
  living = living + getElemState(initial,x-1,y)
  living = living + getElemState(initial,x-1,y+1)
  return living;
}

getElemState = function(initial, x,y){
  if (x<0 || y < 0)
    return 0;
  if (initial.length <= x)
    return 0;
  if (initial[x].length <= y)
    return 0;
  return initial[x][y];
}

new_state = function(initial, cell_index) {
return 0; 
}




