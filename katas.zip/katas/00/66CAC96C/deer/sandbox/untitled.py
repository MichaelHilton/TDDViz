class Untitled:

    def answer(self):
        return 42

