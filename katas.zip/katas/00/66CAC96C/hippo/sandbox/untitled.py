class Untitled():
    alist = []
    def getsize(alist):
        
        the_size = len(alist)
        return the_size

    

