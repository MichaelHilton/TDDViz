import untitled
import unittest

class TestUntitled(unittest.TestCase):

    def test_str(self):
        '''simple example to start you off'''
        
        obj = untitled.Untitled()
        result = obj.getsize()
        print result
        #self.assertEqual(obj.getsize())


if __name__ == '__main__':
    unittest.main()
