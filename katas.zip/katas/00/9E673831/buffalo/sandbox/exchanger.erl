-module(exchanger).
-export([exchange/1]).

exchange({0, cents}) ->
  [];

exchange({X, cents}) when X >= 10  ->
  [{[{X, pennies}]}] ++
    exchangeWithDimes({X, cents});

exchange({X, cents}) when X >= 5  ->
  [{[{X, pennies}]}] ++
    {[] ++ exchangeWithNickels({X, cents})};

exchange({X, cents}) ->
  [{[{X, pennies}]}];

exchange(_) ->
  [].


exchangeWithNickels({5, cents}) ->
  [{1, nickels}];

exchangeWithNickels({X, cents}) when X < 5 ->
  [{X, pennies}];

exchangeWithNickels({X, cents}) when X div 5 > 0 ->
  exchangeWithNickels(X div 5, {X, cents});

exchangeWithNickels({X, cents}) ->
  [{[{X div 5, nickels}, {X rem 5, pennies}]}].



exchangeWithNickels(NumberOfNickels, {_, cents}) when NumberOfNickels == 0 ->
  [];

exchangeWithNickels(NumberOfNickels, {X, cents}) when X - (NumberOfNickels * 5) == 0 ->
  [{[{NumberOfNickels, nickels}]}] ++
    exchangeWithNickels((NumberOfNickels - 1), {X, cents});

exchangeWithNickels(NumberOfNickels, {X, cents}) ->
  [{[{NumberOfNickels, nickels}, {X - (NumberOfNickels * 5), pennies}]}] ++
    exchangeWithNickels((NumberOfNickels - 1), {X, cents}).



exchangeWithDimes({X, cents}) when X rem 10 == 0 ->
  [{[{X div 10, dimes}]}] ++ exchangeWithNickels({X, cents});

exchangeWithDimes({X, cents}) ->
  [{[{X div 10, dimes}] ++ exchangeWithNickels({X-10,cents})}] ++ 
    exchangeWithNickels({X, cents}).

