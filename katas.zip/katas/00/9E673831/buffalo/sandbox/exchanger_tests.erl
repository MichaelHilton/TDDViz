-module(exchanger_tests).
-include_lib("eunit/include/eunit.hrl").
-import(exchanger, [exchange/1]).

exchange_zero_cent_test() ->
  ?assertEqual([], exchanger:exchange({0, cents})).
exchange_zero_dollars_test() ->
  ?assertEqual([], exchanger:exchange({0, dollars})).
exchange_one_cent_test() ->
  ?assertEqual([{[{1, pennies}]}], exchanger:exchange({1, cents})).
exchange_two_cent_test() ->
  ?assertEqual([{[{2, pennies}]}], exchanger:exchange({2, cents})).
exchange_three_cent_test() ->
  ?assertEqual([{[{3, pennies}]}], exchanger:exchange({3, cents})).
exchange_four_cent_test() ->
  ?assertEqual([{[{4, pennies}]} ], 
              exchanger:exchange({4, cents})).
exchange_five_cent_test() ->
  ?assertEqual([
                  {[{5, pennies}] },
                  {[{1,nickels}] }
               ], 
                exchanger:exchange({5, cents})).
exchange_six_cent_test() ->
  ?assertEqual([
                {[{6, pennies}]},
                {[{1,nickels},{1,pennies}]}
               ], 
                exchanger:exchange({6, cents})).
exchange_seven_cent_test() ->
  ?assertEqual([
                {[{7, pennies}]},
                {[{1,nickels},{2,pennies}]}
                ], 
                exchanger:exchange({7, cents})).
exchange_eight_cent_test() ->
  ?assertEqual([
                {[{8, pennies}]},
                {[{1,nickels},{3,pennies}]}
               ], 
                exchanger:exchange({8, cents})).
exchange_nine_cent_test() ->
  ?assertEqual([
                {[{9, pennies}]},
                {[{1,nickels},{4,pennies}]}
               ], 
                exchanger:exchange({9, cents})).
exchange_ten_cent_test() ->
  ?assertEqual([
                {[ {10, pennies} ]},
                {[{1,dimes}]},
                {[{2,nickels}]},
                {[{1,nickels}, {5,pennies}]}
              ], 
                exchanger:exchange({10, cents})).

exchange_eleven_cent_test() ->
  ?assertEqual([
                {[ {11, pennies} ]},
                {[{1,dimes}, {1, pennies}]},
                {[{2,nickels}, {1, pennies}]},
                {[{1,nickels}, {6,pennies}]}
              ], 
                exchanger:exchange({11, cents})).
exchange_twelve_cent_test() ->
  ?assertEqual([
                {[ {12, pennies} ]},
                {[{1,dimes}, {2, pennies}]},
                {[{2,nickels}, {2, pennies}]},
                {[{1,nickels}, {7,pennies}]}
              ], 
                exchanger:exchange({12, cents})).

exchange_thirteen_cent_test() ->
  ?assertEqual([
                {[ {13, pennies} ]},
                {[{1,dimes}, {3, pennies}]},
                {[{2,nickels}, {3, pennies}]},
                {[{1,nickels}, {8,pennies}]}
              ], 
                exchanger:exchange({13, cents})).

exchange_fourteen_cent_test() ->
  ?assertEqual([
                {[ {14, pennies} ]},
                {[{1,dimes}, {4, pennies}]},
                {[{2,nickels}, {4, pennies}]},
                {[{1,nickels}, {9,pennies}]}
              ], 
                exchanger:exchange({14, cents})).
exchange_fifteen_cent_test() ->
  ?assertEqual([
                {[ {15, pennies} ]},
                {[{1,dimes}, {1, nickles}]},
                {[{1,dimes}, {5, pennies}]},
                {[{3,nickels}]},
                {[{2,nickels}, {5, pennies}]},
                {[{1,nickels}, {10,pennies}]}
              ], 
                exchanger:exchange({15, cents})).




%% quarters (25 cents)
%%  dimes (10 cents)
%%  nickels (5 cents) 
%%  pennies (1 cent)

%% There are 6 ways to make change for 15 cents:
%%  A dime and a nickel;
%%  A dime and 5 pennies;
%%  3 nickels;
%%  2 nickels and 5 pennies;
%%  A nickel and 10 pennies;
%%  15 pennies.
