-module(untitled).
-export([answer/0]).

answer() ->
  42.

