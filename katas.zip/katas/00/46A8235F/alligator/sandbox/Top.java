import java.util.*;

public class Top {

    List<String> rows = new ArrayList<String>();

    public Top(char c) {
        for ( String row : new Quad(c).getRows() ) {
            String left = new StringBuilder(row).reverse().toString();
            String right = row.substring(1);
            rows.add(left + right);
        }
    }

    public String toString() {
        String out = "";
        for (String row : rows) {
            out += row + "\n";
        }
        return out;
    }

    public List<String> getRows() {
        return rows;
    }

}