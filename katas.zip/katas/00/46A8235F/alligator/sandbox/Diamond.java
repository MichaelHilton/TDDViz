import java.util.*;

public class Diamond {
    List<String> rows = new ArrayList<String>();

    public Diamond(char c) {
        List<String> tRows = new Top(c).getRows();
        for (String row : tRows ) {
            rows.add(row);
        }
        for (int r = tRows.size()-2 ; r >= 0 ; r--) {
            rows.add(tRows.get(r));
        }
    }

    public String toString() {
        String out = "";
        for (String row : rows) {
            out += row + "\n";
        }
        return out;
    }
}