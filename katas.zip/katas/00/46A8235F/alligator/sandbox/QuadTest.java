import org.junit.*;
import static org.junit.Assert.*;

public class QuadTest {
    
    @Test
    public void quadAPrintsCorrectly() {
        String expected = "A\n";
        Quad a = new Quad('A');
        String actual = a.toString();
        assertEquals(expected,actual);
    }

    @Test
    public void quadBPrintsCorrectly() {
        String expected = 
"A \n" +
" B\n";
        Quad b = new Quad('B');
        String actual = b.toString();
        assertEquals(expected,actual);
    }

    @Test
    public void quadCPrintsCorrectly() {
        String expected = 
"A  \n"+
" B \n"+
"  C\n";
        Quad c = new Quad('C');
        String actual = c.toString();
        assertEquals(expected, actual);
    }

    @Test
    public void quadEPrintsCorrectly() {
        String expected = 
"A    \n"+
" B   \n"+
"  C  \n"+
"   D \n"+
"    E\n";
        Quad e = new Quad('E');
        String actual = e.toString();
        assertEquals(expected, actual);
    }
}
