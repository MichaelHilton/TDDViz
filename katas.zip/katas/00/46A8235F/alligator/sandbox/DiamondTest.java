import org.junit.*;
import static org.junit.Assert.*;

public class DiamondTest {
    @Test
    public void diamondAPrintsCorrectly() {
        String expected = "A\n";
        String actual = new Diamond('A').toString();
        assertEquals(expected,actual);
    }

    @Test
    public void diamondEPrintsCorrectly() {
        String expected = 
"    A    \n"+
"   B B   \n"+
"  C   C  \n"+
" D     D \n"+
"E       E\n"+
" D     D \n"+
"  C   C  \n"+
"   B B   \n"+
"    A    \n";
        String actual = new Diamond('E').toString();
        assertEquals(expected,actual);
    }

}