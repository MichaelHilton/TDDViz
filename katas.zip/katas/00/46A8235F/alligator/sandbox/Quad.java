import java.util.*;

public class Quad {

    List<String> rows = new ArrayList<String>();

    public Quad(char c) {
        char start = 'A';
        fillRows(start, c);
    }

    public void fillRows(char start, char end) {
        int cols = end - start + 1;
        int offset = 0;
        while (offset<cols) {
            rows.add(buffer(offset,charsAfter(start,offset++),cols));
        }
    }

    public String toString() {
        String out = "";
        for (String row : rows) {
            out += row + "\n";
        }
        return out;
    }

    private String buffer(int before, char c, int total) {
        String out = "";
        for (int i = 0 ; i < before ; i++ ) {
            out += " ";
        }
        out += c;
        while (out.length() < total) {
            out += " ";
        }
        return out;
    }

    public List<String> getRows() {
        return rows;
    }

    private char charsAfter(char c, int offset) {
        return Character.toChars(c+offset)[0];
    }
}