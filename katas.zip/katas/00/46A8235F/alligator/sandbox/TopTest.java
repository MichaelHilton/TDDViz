import org.junit.*;
import static org.junit.Assert.*;

public class TopTest {

    @Test
    public void topAPrintsCorrectly() {
        String expected = "A\n";
        Top a = new Top('A');
        String actual = a.toString();
        assertEquals(expected,actual);
    }

    @Test
    public void topBPrintsCorrectly() {
        String expected = 
" A \n"+
"B B\n";
        String actual = new Top('B').toString();
        assertEquals(expected,actual);
    }

    @Test
    public void topEPrintsCorrectly() {
        String expected = 
"    A    \n"+
"   B B   \n"+
"  C   C  \n"+
" D     D \n"+
"E       E\n";
        String actual = new Top('E').toString();
        assertEquals(expected,actual);
    }

}