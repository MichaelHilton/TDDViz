runhaskell *test*.hs
