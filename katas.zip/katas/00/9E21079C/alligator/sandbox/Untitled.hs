module Untitled where

answer = 42

