
using NUnit.Framework;

[TestFixture]
public class UntitledTest
{
    [Test]
    public void HitchHiker()
    {
        string actual = Untitled.Diamond('A');
        Assert.AreEqual(@"
A", actual);
System.Console.WriteLine();
        actual = Untitled.Diamond('B');
        Assert.AreEqual(@"
 A
B B
 A", actual);
System.Console.WriteLine();
        actual = Untitled.Diamond('C');
        Assert.AreEqual(
@"
  A
 B B
C   C
 B B
  A", actual);
System.Console.WriteLine();
        actual = Untitled.Diamond('D');
        Assert.AreEqual(
@"
   A
  B B
 C   C
D     D
 C   C
  B B
   A", actual);
System.Console.WriteLine();
        actual = Untitled.Diamond('E');
        Assert.AreEqual(
@"
    A
   B B
  C   C
 D     D
E       E
 D     D
  C   C
   B B
    A", actual);
    }
}

