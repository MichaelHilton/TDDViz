using System;
using System.Linq;
public class Untitled
{
    public static string Diamond(char letter)
    {
System.Console.WriteLine(letter);

if(letter == 'A')
{
return @"
" + letter.ToString();
}
else if(letter == 'B')
{
var A = ((char)(letter-1)).ToString();
return @"
 " + A + @"
" + letter + ' ' + letter + @"
 " + A;
}
var lll = letter-1;
System.Console.WriteLine("lll: " + lll);
var ll = (char)(lll);
System.Console.WriteLine("ll: " + ll);
var lines = Diamond(ll).Split('\n');
var newLines = lines.Select( line => " " + line.TrimStart('\r'));
var middle = @"
" + letter;
for(int i=0;i<(letter - 'A')*2-1;++i) middle += " ";
middle += "" + letter + @"
";
return newLines.Take(lines.Length/2+1).Aggregate((res, line)=>res + @"
" + line).Substring(1) 
+ middle + 
newLines.Skip(lines.Length/2).Aggregate((res, line)=>res + @"
" + line);
    }
}
