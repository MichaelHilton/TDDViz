require './untitled'

describe "untitled" do
  
  context "when doing sums" do
    it "multiplies correctly" do
      answer.should == (6 * 9)
    end
  end  

end
