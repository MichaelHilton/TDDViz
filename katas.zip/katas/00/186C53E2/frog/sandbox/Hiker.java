
public class Hiker {

    public int answer() {
        return 6 * Config.getInstance().getMultiplier();
    }

}
