#include "fubar.hpp"
#include "widget.hpp"
static widget w;

fubar::fubar()
    : instance_ref_member(w)
{
}