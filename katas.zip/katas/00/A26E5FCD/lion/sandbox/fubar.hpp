#ifndef FUBAR_INCLUDED
#define FUBAR_INCLUDED

//#include "widget.hpp"

class widget;

class fubar // : public widget // 1 inheritance
{
public:

    fubar();

    void value_parameter(widget  ); // 2
    void   ref_parameter(widget &); // 3
    void   ptr_parameter(widget *); // 4

    widget value_return(); // 5
    widget & ref_return(); // 6
    widget * ptr_return(); // 7

 //   widget instance_value_member; //  8
    widget & instance_ref_member; //  9
    widget * instance_ptr_member; // 10

    static widget static_value_member; // 11
    static widget & static_ref_member; // 12
    static widget * static_ptr_member; // 13
};

#endif
