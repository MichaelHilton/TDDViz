#ifndef WIDGET_INCLUDED
#define WIDGET_INCLUDED

class widget
{
};

#endif