#include "untitled.hpp"
#include "gtest/gtest.h"

using namespace ::testing;

TEST(FizzBuzz, returnsANumberAsString)
{
    ASSERT_EQ(FizzBuzz::getFizzBuzz(1), "1");
}

TEST(FizzBuzz, returnsFizzForThree)
{
    ASSERT_EQ(FizzBuzz::getFizzBuzz(3), "Fizz");
}

TEST(FizzBuzz, returns4AsString)
{
    ASSERT_EQ(FizzBuzz::getFizzBuzz(4), "4");
}

TEST(FizzBuzz, returnsBuzzForFive)
{
    ASSERT_EQ(FizzBuzz::getFizzBuzz(5), "Buzz");
}

TEST(FizzBuzz, returnsFizzForSix)
{
    ASSERT_EQ(FizzBuzz::getFizzBuzz(6), "Fizz");
}

TEST(FizzBuzz, returnsFizzBuzzForFifteen)
{
    ASSERT_EQ(FizzBuzz::getFizzBuzz(15), "FizzBuzz");
}
