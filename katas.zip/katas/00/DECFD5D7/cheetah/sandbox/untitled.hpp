#ifndef UNTITLED_INCLUDED
#define UNTITLED_INCLUDED

#include <sstream>

class FizzBuzz
{
public:
    static std::string getFizzBuzz(unsigned int const n)
    {
        std::stringstream ss;
        if (isFizz(n) || isBuzz(n)) {
            if (isFizz(n)) {
                ss << "Fizz";
            }
            if (isBuzz(n)) {
                ss << "Buzz";
            }
        } else {
            ss << n;
        }
        return ss.str();
    }

private:
    static bool isFizz(unsigned int const n)
    {
        return (n % 3 == 0);
    }

    static bool isBuzz(unsigned int const n)
    {
        return (n % 5 == 0);
    }
};

#endif
