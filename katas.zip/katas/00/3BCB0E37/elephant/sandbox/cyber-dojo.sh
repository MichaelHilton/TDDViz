# Test output can be formatted as progress or documentation
rspec . --format progress