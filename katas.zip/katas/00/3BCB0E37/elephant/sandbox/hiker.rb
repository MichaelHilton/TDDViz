
def answer
  6 * 9
end
