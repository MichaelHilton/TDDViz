require './hiker'

describe "hiker" do

  context "life the universe and everything" do
    it "multiplies correctly" do
      answer.should == (42)
    end
  end

end
