
public class Untitled {

    public Untitled(UntitledHelper helper) {
        this.helper = helper;
    }

    public int answer() {
        return helper.answer();
    }

    private UntitledHelper helper;
}
