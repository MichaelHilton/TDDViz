
public class UntitledHelper {

    public int answer() {
        return 42;
    }

}
