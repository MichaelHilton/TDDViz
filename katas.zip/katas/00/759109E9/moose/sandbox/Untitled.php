<?php

function answer()
{
    return 42;
}

?>

