phpunit --verbose .
